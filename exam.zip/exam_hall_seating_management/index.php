<!DOCTYPE html>
<html>
<head><!--header files are added here-->
<title>Student Login:: Seating Arragement</title>
<meta charset="uft=8"/>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Champion Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<!--/header files are added here-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<style>
.conaboutus{
	padding-top:8px;
	padding-left:100px;
	padding-right:150px;
	padding-bottom:1200px;
	height:550px;
	background-image:url(images/custombrown.jpg);
	background-position:center top;
	background-repeat:repeat-y;
	width:100%;
	height:700px;
	color:white;
	background-attachment:scroll;
	
}
</style>
</head>

<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="header-nav">
				<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						<div class="logo">
							<a class="navbar-brand" href="index.html">Seating Arrangement <span>my first project</span></a>
						</div>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					 <ul class="nav navbar-nav">
						<li class="hvr-sweep-to-bottom active"><a href="index.html" class="scroll">About Project</a></li>
						<li class="hvr-sweep-to-bottom"><a href="login.html">Admin Login</a></li>
						<li class="hvr-sweep-to-bottom"><a href="faculty.php" class="scroll">Faculty</a></li>
						<li class="hvr-sweep-to-bottom"><a href="sview.html" class="scroll">Student</a></li>
			
						<li class="hvr-sweep-to-bottom"><a href="register.html" class="scroll">Sign Up</a></li>
					  </ul>
					</div><!-- /.navbar-collapse -->
				</nav>
			</div>
		</div>
	</div>
<!-- //header -->
<div class="conaboutus">
<!--Forms-->
	
   <div class="loginscene"><div class="page-header">
        <h1>Our Team</h1>
		<h2>Exam Seating Arrangement</h2>
      </div>
		<div class="thespeech">Exam Hall Seating Arrangement Systems is developed for the college to simplify examination hall allotment and seating arrangemnt. The project keeps track of each room.
		<br><br>HOW TO USE? (QUICK GUIDE)<br><br>
		For making seating arrangement <br><br>
		<list>
		
		A. ADMIN LOGIN<br>
		
		1.Register yourself on clicking <a href="register.html">Sign Up</a>.<br>
		2.Log In with registered username and password.<br>
		3.Enter room details.<br>
		4.Chart would be prepared.<br><br><br>
		B. UPDATE<br>
		  You can change particular roll numbers with other roll number.<br><br><br>
		C. VIEW<br>
		   You can view seating arrangement of particular room.</br><br><br>
	For students.<br><br>
		1.Click on <a href="sview.html">Student</a>.<br>
		2.Enter your roll number.<br>
		3.Your alloted seat would be shown(if chart prepared).<br><br><br>
		For Invigilators.<br>
		(Invigilators can check their alloted room and timing.)<br><br>
		1.Click on <a href="faculty.php">Faculty</a>.<br>
		2.Enter your name.<br>
		3.Your alloted room will be shown.<br>
		<br>
		(Currently It is available for 8 columns room.)
		
	</div>
</div>
</div>
<!--short codes end here--></div></div>


</body>
</html>